// 接口接收参数类型定义
export interface XXXParams {
  
}

// 接口返回参数类型定义
export interface XXXState {
  
}