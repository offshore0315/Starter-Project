<template>
	<div>个人测试页面2</div>
</template>

<script lang='ts'>
import { defineComponent } from 'vue';
export default defineComponent({
	setup() {
		return {};
	},
});
</script>

<style lang='scss' scoped>
</style>