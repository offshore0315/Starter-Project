<template>
  <view>
    <nut-form>
      <nut-form-item label="姓名">
        <nut-input v-model="basicData.name" class="nut-input-text" placeholder="请输入姓名" type="text" />
      </nut-form-item>
      <nut-form-item label="年龄">
        <nut-input v-model="basicData.age" class="nut-input-text" placeholder="请输入年龄" type="text" />
      </nut-form-item>
      <nut-form-item label="ID">
        <nut-input v-model="basicData.userID" class="nut-input-text" placeholder="请输入id" type="text" />
      </nut-form-item>
    </nut-form>
    <nut-button type="info" @click="submit">信息按钮</nut-button>
  </view>
</template>
<script lang="ts" setup>
import { ref, reactive } from 'vue';

// 引入stores
import {useKeepALiveNames} from "@/stores/keepAliveNames"

interface BasicDataType {
  name: string,
  age: Number,
  userID: string
}
// 初始化
const userStore = useKeepALiveNames()

const basicData: BasicDataType = reactive({
  name: '',
  age: 0,
  userID: ''
})


const submit = () => {
  // 直接调用里面的方法和数据
  userStore.setUserInfo(basicData)
  console.log(userStore.userInfo);
  
}
</script>