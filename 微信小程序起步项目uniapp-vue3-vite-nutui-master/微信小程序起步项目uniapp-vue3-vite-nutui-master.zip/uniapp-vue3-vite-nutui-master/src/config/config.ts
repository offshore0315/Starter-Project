// 项目公共配置

import type { AppConfig } from "@/interfaces/config"

const appConfig:AppConfig = {
	//  其他公共参数配置
	tokenKey: 'token',
	historySearchKey: 'local-history-search',
	apiUrl: ""
}

// apiUrl:process.env.NODE_ENV == 'development' ? 'http://192.168.0.104:4000/' : 'https://apitc.codingtalk.cn/'
// ossUrl:process.env.NODE_ENV == 'development' ? '//codingtalk-imgtest.oss-cn-shenzhen.aliyuncs.com/' : '//img.codingtalk.cn/'
// export default {
// 	install:function(Vue){
// 		Vue.prototype.$config = config
// 	},
// 	...config
// }
export default appConfig