import {
	request
} from '@/libs/request.js'
import type {Config} from '@/interfaces/config'


export function APIText(object: any) {
	const url = '/api_1_0/DiningMenuItem/query'
	const params = {}
	const data = object
	const config:Config = {
		method: 'GET',
		showLoading: false,
		base_url: '',
		requireLogin: false,
		forceLogin: false
	}
	return request.send(url, data, config)
}