import { defineStore } from 'pinia';
import { token } from "@/utils/token"

interface UserInfo {
	name: string,
	age: Number,
	userID: string,
	token: string
}

export const useKeepALiveNames = defineStore('keepALiveNames', {
	state: (): { userInfo: UserInfo, isLogin: boolean } => ({
		userInfo: {
			name: '',
			age: 0,
			userID: '',
			token: ''
		},
		isLogin: false
	}),
	actions: {
		setUserInfo(data: Partial<UserInfo>): void {
			this.userInfo = { ...this.userInfo, ...data };
			this.isLogin = true
			if (this.userInfo.token) {
				token.set(this.userInfo.token)
			}
		},
		logout() {
			this.userInfo = {
				name: '',
				age: 0,
				userID: '',
				token: ''
			};
			this.isLogin = false;
			token.clear()
		},
	},
});
