import { defineStore } from 'pinia';

export const useKeepALiveNames = defineStore('keepALiveNames', {
	state: () => ({
		
	}),
	actions: {
	},
});
