import { request } from '@/libs/request.ts'
import type { Config } from '@/interfaces/config'

export function useNewsApi() {
  return {
    getRecommendNews: (params: object) => {
      const url = '/news/recommendNews'
      const config: Config = {
        method: 'GET',
        showLoading: false,
        base_url: '',
        requireLogin: false,
        forceLogin: false,
      }
      return request.send(url, params, config)
    }
  }
}
