import { request } from '@/libs/request.ts'
import type { Config } from '@/interfaces/config'

export function useLoginApi() {
  return {
    signIn: (params: object) => {
      const url = '/studentInfo/login'
      const config: Config = {
        method: 'POST',
        showLoading: false,
        base_url: '',
        requireLogin: false,
        forceLogin: false,
      }
      return request.send(url, params, config)
    },
    signOut: (params: object) => {
    },
  }
}
