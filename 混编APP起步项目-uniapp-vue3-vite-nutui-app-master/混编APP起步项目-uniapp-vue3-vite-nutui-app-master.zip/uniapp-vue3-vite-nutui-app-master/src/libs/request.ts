import appConfig from '@/config/config'
import type {Config} from '@/interfaces/config'
import {
	token
} from '@/utils/token'

const doLogin = () => {
	uni.navigateTo({
		url: "/pages/login/index"
	})
}

const post = (url: string, data: any, config: Config) => {
	Object.assign
	const defaultConfig:Config = {
		method: 'POST',
		showLoading: true,
		base_url: '',
		requireLogin: false,
		forceLogin: false
	}
	const finalConfig:Config = config ? Object.assign(defaultConfig, config) : defaultConfig
	
	finalConfig.showLoading && uni.showLoading({
		title: '加载中'
	});
	return new Promise((resolve) => {
		if (finalConfig.requireLogin && !token.get()) {
			if (finalConfig.forceLogin) {
				doLogin()
			}
			resolve({
				status: false
			})
			return
		}
		uni.request({
			method: finalConfig.method,
			url: (finalConfig.base_url ? finalConfig.base_url : appConfig.apiUrl) + url,
			data: data,
			// timeout: 5000,
			header: (() => {
				const tokeValue = token.get()
				let config = {
					'content-type': 'application/x-www-form-urlencoded'
				}
				if (tokeValue) {
					// config[appConfig.tokenKey as string] = tokeValue
					const key = appConfig.tokenKey as keyof typeof config;
  				config[key] = tokeValue;
				}
				return config
			})(),
			success: (res) => {
				const {
					code,
					data
				} = res.data as any
				if (code === '4001') {
					let routes = getCurrentPages()
					let curRoute = routes[routes.length - 1].route
					if (curRoute != 'pages/login/login') {
						uni.showToast({
							title: '请重新登陆',
							icon: 'error',
							duration: 1500
						});
						setTimeout(() => {
							// token.clear()
							doLogin()
						}, 1500)
					}
				}
				resolve(res.data)
			},
			complete: () => {
				finalConfig.showLoading && uni.hideLoading()
			}
		})
	})
}

export const request = {
	send: (url: any, data: any, config: Config) => {
		return post(url, data, config)
	}
}
