
interface Config {
  method?: 'OPTIONS' | 'GET' | 'HEAD' | 'POST' | 'PUT' | 'DELETE' | 'TRACE' | 'CONNECT'; 
  showLoading?: boolean; 
  base_url?: string; 
  requireLogin?: boolean; 
  forceLogin?: boolean;
}

interface AppConfig {
  tokenKey?: string; 
	historySearchKey?: string; 
	apiUrl?: string; 
}

export type {Config,AppConfig}