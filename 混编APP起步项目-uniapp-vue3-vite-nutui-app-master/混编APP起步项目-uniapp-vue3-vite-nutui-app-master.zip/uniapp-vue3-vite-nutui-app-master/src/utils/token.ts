import appConfig from '@/config/config'

export const token = {
    set: (s: any) => {
        if (appConfig.tokenKey !== undefined) {
            uni.setStorageSync(appConfig.tokenKey, s)
        }
    },
    get: () => {
        if (appConfig.tokenKey !== undefined) {
            return uni.getStorageSync(appConfig.tokenKey)
        }

    },
    clear: () => {
        if (appConfig.tokenKey !== undefined) {
            uni.removeStorageSync(appConfig.tokenKey)
        }

    }
}
