<template>
  <view class="page">
    <view class="my-logo">
      <img src="@/static/images/logo.jpg">
    </view>
    <view class="login-form">
      <fui-input class="login-form-item" trim required clearable label="用户" borderTop placeholder="请输入文本"
        v-model="state.userName"></fui-input>
      <fui-input class="login-form-item" trim required clearable password label="密码" :bottomLeft="0" placeholder="请输入文本内容"
        v-model="state.password"></fui-input>
    </view>
    <view class="btn">
      <view class="btn-item">
        <fui-button height="2.5rem" @click="onHandleLogin">登录</fui-button>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { reactive } from 'vue';
import { useLoginApi } from "@/api/login"
const loginApi = useLoginApi()

const state = reactive({
  userName: "120201080408",
  password: "120201080408"
})

const goPage = () => {
  uni.reLaunch({
    url: `/pages/home/index`
  })
}

// 处理登录
const onHandleLogin = () => {
  const params = {
    student_number: 120201080408,
    password: "NcNa0O/CVpy4Nux4gBYmS3ZEexm9WRcezwEH7LcQ0Qw3qT64FSWFHROSrM9AnFKiNLZpRmeu4+jGGkC93q2KJQ=="
  }
  // loginApi.signIn(params)
  // .then(res => {
  //   goPage()
  //   console.log(res)
  // })

  // 绕过接口，直接进入
  goPage()

}
</script>

<style scoped>
.my-logo {
  margin-top: 30px;
  width: 100%;
  display: flex;
  justify-content: center;
}

img {
  width: 280px;
}

.login-form {
  margin-top: 100px;
  display: flex;
  flex-direction: column;
}

.login-form .login-form-item {
  margin: 10px 30px;
  width: 90%;
}

.btn {
  margin-top: 70px;
  width: 100%;
  display: flex;
  justify-content: center;
}

.btn .btn-item {
  width: 50%;
}
</style>