<template>
  <view class="content">
    <image class="logo" src="/static/logo.png" />
    <view class="text-area">
      你好世界
      <text class="title">{{ title }}</text>
    </view>
    <fui-button height="2.5rem" text="默认按钮"></fui-button>
	<fui-button height="2.5rem"  type="success" @click="onHandleLogin">登录</fui-button>
  <view>
    新闻列表
    <view v-for="(item,index) in state.newsList" :key="index">{{ item.club_name }}</view>
  </view>
  </view>
</template>

<script setup lang="ts">
interface News {
  club_name:string
}

import { ref,reactive, onMounted } from 'vue'
import { useLoginApi } from "@/api/login"
import { useNewsApi } from "@/api/news"
const state = reactive({
  text: "测试文本",
  newsList:[] as News[]
})
const title = ref("hello")
const loginApi = useLoginApi()
const newsApi = useNewsApi()
onMounted(() => {
  getRecommendNews()
})
const onHandleClick = () => {
  console.log("hello world")
}
// 处理登录
const onHandleLogin = () => {
  const params = {
    student_number: 120201080408,
    password: "NcNa0O/CVpy4Nux4gBYmS3ZEexm9WRcezwEH7LcQ0Qw3qT64FSWFHROSrM9AnFKiNLZpRmeu4+jGGkC93q2KJQ=="
  }
  loginApi.signIn(params)
  .then(res => {
    console.log(res)
  })
}
// 获取新闻列表
const getRecommendNews = () => {
  const params = {
    page: 1,
    size: 10
  }
  newsApi.getRecommendNews(params)
  .then((res:any) => {
    state.newsList = res.data
  })
}
</script>

<style>
.content {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.logo {
  height: 200rpx;
  width: 200rpx;
  margin-top: 200rpx;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 50rpx;
}

.text-area {
  display: flex;
  justify-content: center;
}

.title {
  font-size: 36rpx;
  color: #8f8f94;
}
</style>
