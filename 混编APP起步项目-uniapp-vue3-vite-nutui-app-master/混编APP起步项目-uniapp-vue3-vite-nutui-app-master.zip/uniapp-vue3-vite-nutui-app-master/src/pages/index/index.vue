<template>
  <view class="MyPage">
    <view class="container">
      <view class="swiper-container">
        <swiper class="MySwiper" :indicator-dots="swiperState.indicatorDots" :autoplay="swiperState.autoplay"
          :circular="swiperState.circular">
          <swiper-item>
            <view class="swiper-item">
              <image class="uimg" src='@/static/images/pic2.jpg'></image>
            </view>
          </swiper-item>
          <swiper-item class="swiper-item">
            <view class="swiper-item">
              <image class="uimg" src='@/static/images/pic3.jpg'></image>
            </view>
          </swiper-item>
          <swiper-item class="swiper-item">
            <view class="swiper-item">
              <image class="uimg" src='@/static/images/pic4.jpg'></image>
            </view>
          </swiper-item>
        </swiper>
      </view>
      <view class="btn-group">
        <view class="btn">
          <view class="btn-item">
            <fui-button height="2.5rem" @click="goPage('/login/index')">登录</fui-button>
          </view>
          <view class="btn-item">
            <fui-button height="2.5rem" @click="goPage('/login/register')">免费注册</fui-button>

          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { reactive } from 'vue';

const state = reactive({
  interval: 2000,
  duration: 500,
})
// 在 setup 函数中定义 swiperState 对象
const swiperState = {
  indicatorDots: false,         // 是否显示面板指示点
  indicatorColor: 'rgba(0, 0, 0, .3)',   // 指示点颜色
  indicatorActiveColor: '#000000',      // 当前选中的指示点颜色
  autoplay: true,              // 是否自动切换
  current: 0,                   // 当前所在滑块的 index
  duration: 500,                // 滑动动画时长（单位 ms）
  circular: true,              // 是否采用衔接滑动
  vertical: false,              // 滑动方向是否为纵向
  previousMargin: '0px',        // 前边距（rpx）
  nextMargin: '0px',            // 后边距（rpx）
  snapToEdge: false,            // 切换效果是否为直接滑动而非滑动过程中停留部分
  eventid: 'swiper',            // 当前组件的唯一标识符，用于在页面滑动的时候监听 bindchange 事件
};

const goPage = (page: string) => {
  if (!page) {
    return false;
  }
  uni.navigateTo({
    url: `/pages${page}`,
  });
}

</script>

<style >
.MyPage {
  height: 100vh;
  width: 100%;
}

.container {
  position: relative;
}

.MySwiper {
  height: 100vh;
}

.swiper-item .uimg {
  position: relative;
  height: 100vh;
  width: 100%;
  object-fit: contain;
}

.swiper-item .uimg::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(to bottom, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.4) 60%);
}

.btn-group {
  position: absolute;
  bottom: 10px;
  width: 100%;
}

.btn {
  display: flex;
  justify-content: space-between;
}

.btn .btn-item {
  flex: 1;
  margin: 0px 10px;
}

.btn .btn:nth-child(2) {
  background-color: #1ba5fb;
  color: #fff;
}
</style>