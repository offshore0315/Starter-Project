<template>
  <view>
    <fui-card :src="src" title="标题文字" tag="额外信息">
      <view class="fui-card__content">这是一个基础卡片的示例，此处为自定义内容区域，自行控制内容样式。</view>
    </fui-card>
    <fui-card :src="src" title="标题文字" tag="额外信息">
      <view class="fui-card__content">这是一个基础卡片的示例，此处为自定义内容区域，自行控制内容样式。</view>
    </fui-card>
    <fui-card :src="src" title="标题文字" tag="额外信息">
      <view class="fui-card__content">这是一个基础卡片的示例，此处为自定义内容区域，自行控制内容样式。</view>
    </fui-card>
  </view>
</template>

<script setup lang="ts">
import logo from "@/static/logo.png"
const src = logo

</script>

<style scoped></style>