<template>
  <view class="MyPage">
    <view class="contentBody">
      <Home :cur="state.pageCur" v-if="state.pageCur === 'home'" :key="state.commponent1Key"></Home>
      <Find v-if="state.pageCur === 'find'" :key="state.commponent2Key"></Find>
      <Order v-if="state.pageCur === 'order'" :key="state.commponent3Key"></Order>
      <My v-if="state.pageCur === 'my'" :key="state.commponent4Key"></My>

      <view class="navbar">
        <view :class="{ 'action': true, 'text-green': state.pageCur === 'home', 'text-gray': state.pageCur !== 'home' }"
          @click="navChange('home')">
          <view class="bar-item">
            <view class="bar-icon">
              <fui-icon :name="state.pageCur === 'home' ? 'home-fill' : 'home'"
                :color="state.pageCur === 'home' ? '#009fff' : 'black'" :size="50"></fui-icon>
            </view>
            <view class='bar-text'>首页</view>
          </view>
        </view>
        <view :class="{ 'action': true, 'text-green': state.pageCur === 'find', 'text-gray': state.pageCur !== 'find' }"
          @click="navChange('find')">
          <view class="bar-item">
            <view class="bar-icon">
              <fui-icon name="search" :color="state.pageCur === 'find' ? '#009fff' : 'black'" :size="50"></fui-icon>
            </view>
            <view class='bar-text'>发现</view>
          </view>
        </view>
        <view class="add-action"
          :class="{ 'action': true, 'text-green': state.pageCur === 'order', 'text-gray': state.pageCur !== 'order' }"
          @click="navChange('order')">
          <view class="bar-item">
            <view class="bar-icon">
              <fui-icon :name="state.pageCur === 'order' ? 'order-fill' : 'order'"
                :color="state.pageCur === 'order' ? '#009fff' : 'black'" :size="50"></fui-icon>
            </view>
            <view class='bar-text'>订单</view>
          </view>
        </view>
        <view :class="{ 'action': true, 'text-green': state.pageCur === 'my', 'text-gray': state.pageCur !== 'my' }"
          @click="navChange('my')">
          <view class="bar-item">
            <view class="bar-icon">
              <fui-icon :name="state.pageCur === 'my' ? 'my-fill' : 'my'"
                :color="state.pageCur === 'my' ? '#009fff' : 'black'" :size="50"></fui-icon>
            </view>
            <view class='bar-text'>我的</view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';

import Home from '@/pages/home/home.vue'
import Find from '@/pages/find/index.vue'
import Order from '@/pages/order/index.vue'
import My from '@/pages/my/index.vue'

const state = reactive({
  commponent1Key: 0,
  commponent2Key: 0,
  commponent3Key: 0,
  commponent4Key: 0,
  pageCur: ref('home'),
});

const navChange = (cur: string) => {
  state.pageCur = cur;
};

onMounted(() => {
  state.pageCur = 'home';
  ++state.commponent1Key;
  ++state.commponent2Key;
  ++state.commponent3Key;
  ++state.commponent4Key;
});
</script>

<style scoped>
.MyPage {
  height: 100vh;
  /* 使用视口高度填充整个屏幕 */
}

.contentBody {
  position: relative;
  /* 相对定位，用于底部导航的固定在底部 */
  height: calc(100% - 60px);
  /* 减去底部导航栏高度，避免被底部导航栏遮挡 */
}

.navbar {
  height: 70px;
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: space-around;
  align-items: center;
  background-color: #fff;
  border-top: 1px solid #ccc;
}

.action {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-decoration: none;
  padding: 10px 0;
}

.text-green {
  color: #009fff;
  /* 激活状态的颜色 */
}

.text-gray {
  color: #333;
  /* 非激活状态的颜色 */
}

.bar-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  /* 居中对齐 */
  justify-content: center;
  /* 在主轴方向上居中 */
}</style>
