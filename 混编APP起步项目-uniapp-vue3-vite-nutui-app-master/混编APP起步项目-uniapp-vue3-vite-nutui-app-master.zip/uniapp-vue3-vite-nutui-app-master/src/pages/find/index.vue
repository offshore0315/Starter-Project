<template>
  <view>
    <fui-list bottomBorder title="新闻列表">
      <fui-list-cell :highlight="false">{{ state.text }}</fui-list-cell>
      <fui-list-cell :bottomBorder="false" :highlight="false" arrow>标题文字</fui-list-cell>
    </fui-list>
  </view>
</template>

<script setup lang="ts">
interface News {
  club_name:string
}

import { ref,reactive, onMounted } from 'vue'
import { useNewsApi } from "@/api/news"
const state = reactive({
  text: "测试文本",
  newsList:[] as News[]
})

const newsApi = useNewsApi()
onMounted(() => {
  getRecommendNews()
})

// 获取新闻列表
const getRecommendNews = () => {
  const params = {
    page: 1,
    size: 10
  }
  newsApi.getRecommendNews(params)
  .then((res:any) => {
    state.newsList = res.data
  })
}
</script>

<style scoped></style>