<template>
  <view>
    <view class="btn">
      <view class="btn-item">
        <fui-button width="500px" height="2.5rem" :loading="state.loading" @click="goPage('/index/index')">退出登录</fui-button>

      </view>
    </view>

  </view>
</template>

<script setup lang="ts">
import { reactive } from 'vue';

const state = reactive({
  loading:false
})
const goPage = (url: string) => {
  state.loading = true
  setTimeout(()=>{
    uni.reLaunch({
    url: `/pages${url}`
  })
  state.loading = false
  },1000)
 
}
</script>

<style scoped>
.btn{
  display: flex;
  justify-content: center;
}
</style>
